import 'package:flutter/material.dart';
import 'package:sports_visio/screens/sign_in_screen.dart';
import 'package:sports_visio/screens/sign_up_screen.dart';
import 'package:sports_visio/screens/user_details_screen.dart';

class Routes {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case SignInScreen.TAG:
        return MaterialPageRoute(builder: (_) => SignInScreen());
      case SignUpScreen.TAG:
        return MaterialPageRoute(builder: (_) => SignUpScreen()); case UserDetailsScreen.TAG:
        return MaterialPageRoute(builder: (_) => UserDetailsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${settings.name}'),
            ),
          ),
        );
    }
  }
}
